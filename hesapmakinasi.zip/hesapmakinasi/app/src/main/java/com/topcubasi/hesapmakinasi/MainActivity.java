package com.topcubasi.hesapmakinasi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
TextView tvSonuc;
EditText etSayi1, etSayi2;
Button btnTopla, btnCikar, btncarp, btnBol, btnsil;
int s1,s2,sonuc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etSayi1 = findViewById(R.id.etSayi1);
        etSayi2 = findViewById(R.id.etSayi2);
        tvSonuc=findViewById(R.id.tvSonuc);
        btncarp=findViewById(R.id.btnCarp);
        btnBol=findViewById(R.id.btnBol);
        btnTopla=findViewById(R.id.btnTopla);
        btnCikar=findViewById(R.id.btnCikar);
        btnsil=findViewById(R.id.btnSil);

        btnTopla.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sayi1=etSayi1.getText().toString();
                s1=Integer.parseInt(sayi1);
                s2=Integer.parseInt(etSayi2.getText().toString());
                sonuc=s1+s2;
                tvSonuc.setText(s1+" + "+s2+" = "+sonuc);
            }
        });
        btnCikar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sayi1=etSayi1.getText().toString();
                s1=Integer.parseInt(sayi1);
                s2=Integer.parseInt(etSayi2.getText().toString());
                sonuc=s1-s2;
                tvSonuc.setText(s1+" - "+s2+" = "+sonuc);
            }
        });
        btncarp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sayi1=etSayi1.getText().toString();
                s1=Integer.parseInt(sayi1);
                s2=Integer.parseInt(etSayi2.getText().toString());
                sonuc=s1*s2;
                tvSonuc.setText(s1+" * "+s2+" = "+sonuc);
            }
        });
        btnBol.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sayi1=etSayi1.getText().toString();
                s1=Integer.parseInt(sayi1);
                s2=Integer.parseInt(etSayi2.getText().toString());
                sonuc=s1/s2;
                tvSonuc.setText(s1+" / "+s2+" = "+sonuc);
            }
        });
        btnsil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etSayi1.setText("");
                etSayi2.setText("");
                tvSonuc.setText(null);
            }
        });
    }
}